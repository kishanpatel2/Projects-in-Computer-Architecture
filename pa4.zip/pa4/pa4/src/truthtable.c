/* CS 211 PA4
 * Created for: kpp95
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

struct command {
    char valuesOfG[17];
    int *develop;
    int *choose;
    int adjacent;
    int size;
    int *augment;

   };

void reopenNumbers(int size, int *count) {
    int a = 0;
    while(a < size){
    	count[a] = 0;
	a++;
    }
    count[1] = 1;

   }

void inverterForAND(int *pointer, int secondpointer, int thirdpointer, int pointTo) {
    pointer[pointTo] = pointer[secondpointer] && pointer[thirdpointer];
   }
void binaryM(int *pointer, int adjacent, int *point, int *pointer1, int pointTo) {
    int size = 0;
    int a = 0;
    while(a < adjacent){
	size += pointer[pointer1[a]] * pow(2, adjacent - a - 1);
	a++;
  }
    pointer[pointTo] = pointer[point[size]];
  }

void valuesP(int size, char **count) {
    int a = 0;
    while(a < size){
	printf("%size\n", count[a]);
	a++;

   }
    
   }

void inverterForNOT(int *pointer, int point, int pointTo) {
    pointer[pointTo] = !pointer[point];
  }

void inverterForOR(int *pointer, int secondpointer, int thirdpointer, int pointTo) {
    pointer[pointTo] = pointer[secondpointer] || pointer[thirdpointer];
   }

void inverterForNOR(int *pointer, int secondpointer, int thirdpointer, int pointTo) {
    pointer[pointTo] = !(pointer[secondpointer] || pointer[thirdpointer]);
  }




void binaryD(int *pointer, int adjacent, int *point, int *pointTo) {
    int size = 0;
    int a = 0;
	while(a < pow(2,adjacent)){
	pointer[pointTo[a]] = 0;
	a++;
  }
   
	while(a < adjacent){
	size += pointer[point[a]] * pow(2, adjacent - a - 1);
	a++;
  }
   for (int a = 0; a < adjacent; a++) {
       size += pointer[point[a]] * pow(2, adjacent - a - 1);
   }
    pointer[pointTo[size]] = 1;
  }

void inverterForNAND(int *pointer, int secondpointer, int thirdpointer, int pointTo) {
    pointer[pointTo] = !(pointer[secondpointer] && pointer[thirdpointer]);
   }

int bignumber(int *count, int amount) {

    for (int a = amount + 1; a >= 2; a--) {
        count[a] = !count[a];
        if (count[a] == 1) {
            return 1;
        }
    }
    return 0;
  }

void inverterForPASS(int *pointer, int point, int pointTo) {
    pointer[pointTo] = pointer[point];
   }

int pointerTo(int size, char **count, char *var) {

    for (int a = 0; a < size; a++) {
        if (strcmp(count[a], var) == 0) {
            return a;
        }
    }
    return -1;
}

void inverterForXOR(int *pointer, int secondpointer, int thirdpointer, int pointTo) {
    pointer[pointTo] = pointer[secondpointer] ^ pointer[thirdpointer];
   }

int main(int argc, char** argv) {

    FILE *file = fopen(argv[1], "r");
    if (!file) {
        printf("Invalid input\n");
        return 0;
    }

    int amount = 1;
    int amountOne = 1;
    int size = 2;
    struct command* pathway = NULL;
    char gvalues[17];
    char **title;

    fscanf(file, " %size", gvalues);
    fscanf(file, "%d", &amount);

    size += amount;
    title = malloc(size * sizeof(char *));
    title[0] = malloc(2 * sizeof(char));
    title[0] = "0\0";
    title[1] = malloc(2 * sizeof(char));
    title[1] = "1\0";

    int a = 0;
    while(a < amount){
        title[a + 2] = malloc(17 * sizeof(char));
        fscanf(file, "%*[: ]%16s", title[a + 2]);
	a++;
}

    fscanf(file, " %size", gvalues);
    fscanf(file, "%d", &amountOne);
    size += amountOne;
    title = realloc(title, size * sizeof(char *));
    for (a = 0; a < amountOne; a++) {
        title[a + amount + 2] = malloc(17 * sizeof(char));
        fscanf(file, "%*[: ]%16s", title[a + amount + 2]);
    }

    int amountTwo = 0;
    int total = 0;
    while (!feof(file)) {
        int integeraug = 2, integerout = 1;
        struct command measure;
        int i = fscanf(file, " %size", gvalues);
        if (i != 1) {
            break;
        }
        total++;
        measure.adjacent = 0;
        measure.size = 0;
        strcpy(measure.valuesOfG, gvalues);

        if (strcmp(gvalues, "NOT") == 0) {
            integeraug = 1;
        }
        if (strcmp(gvalues, "DECODER") == 0) {
            fscanf(file, "%d", &integeraug);
            measure.adjacent = integeraug;
            integerout = pow(2, integeraug);
        }
        if (strcmp(gvalues, "MULTIPLEXER") == 0) {
            fscanf(file, "%d", &integeraug);
            measure.size = integeraug;
            integeraug = pow(2, integeraug);
        }

        measure.augment = malloc(integeraug * sizeof(int));
        measure.develop = malloc(integerout * sizeof(int));
        measure.choose = malloc(measure.size * sizeof(int));

        char gvalue[17];
        for (a = 0; a < integeraug; a++) {
            fscanf(file, "%*[: ]%16s", gvalue);
            measure.augment[a] = pointerTo(size, title, gvalue);
        }

        for (a = 0; a < measure.size; a++) {
            fscanf(file, "%*[: ]%16s", gvalue);
            measure.choose[a] = pointerTo(size, title, gvalue);
        }

        for (a = 0; a < integerout; a++) {
            fscanf(file, "%*[: ]%16s", gvalue);
            int realNumber = pointerTo(size, title, gvalue);
            if (realNumber == -1) {
                size++;
                amountTwo++;
                title = realloc(title, size * sizeof(char *));
                title[size - 1] = malloc(17 * sizeof(char));
                strcpy(title[size - 1], gvalue);
                measure.develop[a] = size - 1;
            }
            else {
                measure.develop[a] = realNumber;
            }
        }


        if (!pathway) {
            pathway = malloc(sizeof(struct command));
        } else {
            pathway = realloc(pathway, total * sizeof(struct command));
        }
        pathway[total - 1] = measure;
    }

    int *pointToThis = malloc(size * sizeof(int));
    pointToThis = malloc(size * sizeof(int));
    reopenNumbers(size, pointToThis);

    while(0 < 1) {

        for (a = 0; a < amount; a++) {
            printf("%d ", pointToThis[a + 2]);
        }
        printf("|");

        for (a = 0; a < total; a++) {
            struct command measure = pathway[a];
            if (strcmp(measure.valuesOfG, "NOT") == 0) {
                inverterForNOT(pointToThis, measure.augment[0], measure.develop[0]);
            }

            else if (strcmp(measure.valuesOfG, "DECODER") == 0) {
                binaryD(pointToThis, measure.adjacent, measure.augment, measure.develop);
            }

            else if (strcmp(measure.valuesOfG, "MULTIPLEXER") == 0) {
                binaryM(pointToThis, measure.size, measure.augment, measure.choose, measure.develop[0]);
            }

            else if (strcmp(measure.valuesOfG, "AND") == 0) {
                inverterForAND(pointToThis, measure.augment[0], measure.augment[1], measure.develop[0]);
            }

            else if (strcmp(measure.valuesOfG, "OR") == 0) {
                inverterForOR(pointToThis, measure.augment[0], measure.augment[1], measure.develop[0]);
            }

            else if (strcmp(measure.valuesOfG, "NAND") == 0) {
                inverterForNAND(pointToThis, measure.augment[0], measure.augment[1], measure.develop[0]);
            }

            else if (strcmp(measure.valuesOfG, "NOR") == 0) {
                inverterForNOR(pointToThis, measure.augment[0], measure.augment[1], measure.develop[0]);
            }

            else if (strcmp(measure.valuesOfG, "XOR") == 0) {
                inverterForXOR(pointToThis, measure.augment[0], measure.augment[1], measure.develop[0]);
            }
            

        }

        for (a = 0; a < amountOne; a++) {
            printf(" %d", pointToThis[amount + a + 2]);
        }
        printf("\n");

        if (!bignumber(pointToThis, amount)) {
            break;
        }
    }

    return 0;
}

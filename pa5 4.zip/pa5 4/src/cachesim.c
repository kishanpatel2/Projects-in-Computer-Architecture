/* CS 211 PA4
 * Created for: kpp95
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include <limits.h>

   typedef struct Cache{
      unsigned int reasonable;
      unsigned long int label;
      unsigned long int substitute;
      long int substitute1;
}

    Cache;
    int strike = 0;
    int miss = 0;
    int numR = 0;
    int numW = 0;
    long int press = 0;
    Cache** cache;
    unsigned long int hint(unsigned long int, int);
    unsigned long int hint(unsigned long int inscription, int proceed){
        return inscription >> proceed;
}

    unsigned long int sIndex(unsigned long int, int, int);
    unsigned long int sIndex(unsigned long int inscription, int segment,int sIndexb){
        return (inscription >> segment) & ((1 << sIndexb) - 1);
}
    int eCredti(char*);
    int eCredti(char* bo){
        if(strcmp("fifo", bo) == 0){
            return 0;
    }
    return 1;
}

    int cacheArea(char**);
    int cacheArea(char** arg){
        return atoi(arg[1]);
}

    char* tracedoc(char**);
    char* tracedoc(char** arg){
        return arg[5];
}
    int blockArea(char**);
    int blockArea(char** arg){
        return atoi(arg[4]);
}

    int setNumber(char**);
    int setNumber(char** arg){
        char* related = arg[2];
    int cache5 = cacheArea(arg);
    int block5 = blockArea(arg);

    if(strcmp("direct", related)==0){
        return cache5 / block5;
    }

    if(strcmp("assoc", related)==0){
        return 1;
    }

    char integerN[1000];
    
   // while(i < strlen(related) && j < 1000){
	//integerN[j]=related[i];
	//i++;
	//j++;
    for(int i = 6, j = 0; i < strlen(related) && j < 1000; i++, j++){
        integerN[j]=related[i];
   }
    return cache5 / block5 / atoi(integerN);
    
}

    int narrowA(char**);
    int narrowA(char** arg){
        char* related = arg[2];
    int cache5 = cacheArea(arg);
    int block5 = blockArea(arg);
    if(strcmp("direct", related) == 0){
        return 1;
    }
    if(strcmp("assoc", related) == 0){
        return cache5 / block5;
    }
    char integerN[1000];
    for(int i = 6, j = 0; i < strlen(related) && j < 1000; i++, j++){
        integerN[j]=related[i];
    }

    return atoi(integerN);

}
    Cache** initialize(char**);
    Cache** initialize(char** arg){
        int setnumber=setNumber(arg);
    int associate = narrowA(arg);
    cache = (struct Cache **) malloc (sizeof( struct Cache) * setnumber);
    for(int i = 0; i < setnumber; i++){
        cache[i] = (struct Cache *) malloc (sizeof( struct Cache) * associate);
        for(int j = 0; j < associate; j++){
            cache[i][j].substitute = 0;
            cache[i][j].label = 0;
            cache[i][j].reasonable = 0;
            cache[i][j].substitute1 = 0;
        }
    }
    strike = 0;
    press = 0;
    miss = 0;
    numR= 0 ;
    numW= 0 ;
    return cache;
}
    void print(){

}
    void prefetch1(int , unsigned long int ,unsigned long int );
    void prefetch1(int associate, unsigned long int secondSIndex,unsigned long int secondTIndex){
        for(int i = 0; i < associate; i++){
            if(cache[secondSIndex][i].reasonable == 1 && cache[secondSIndex][i].label == secondTIndex){
            break;
        }
        else if(cache[secondSIndex][i].reasonable == 1 && associate == i + 1){
            numR++;
            long int highestN = LONG_MAX;
            for(int j = 0; j < associate; j++){
                if(highestN >= cache[secondSIndex][j].substitute){
                    highestN = cache[secondSIndex][j].substitute;
                }
            }
            for(int j = 0; j < associate; j++){
                if(highestN == cache[secondSIndex][j].substitute){
                    cache[secondSIndex][j].label = secondTIndex;
                    cache[secondSIndex][j].substitute = press;
                    press++;
                    break;
                }
            }
            return;
        }else if(cache[secondSIndex][i].reasonable == 0){
            numR++;
            cache[secondSIndex][i].reasonable = 1;
            cache[secondSIndex][i].label=secondTIndex;
            cache[secondSIndex][i].substitute = press;
            press++;
            break;
        }
        else
            continue;
    }
}
    void prefetchclrue(int, unsigned long int, unsigned long int);
    void prefetchclrue(int associate, unsigned long int secondSIndex, unsigned long int secondTIndex){
        for(int i = 0; i < associate; i++){
            if(cache[secondSIndex][i].reasonable == 1 && cache[secondSIndex][i].label == secondTIndex){
            break;

            }
        else if(cache[secondSIndex][i].reasonable == 1 && associate == i + 1){
            numR++;
            long int highestN = LONG_MAX;
            for(int j = 0;j < associate; j++){
                if(highestN >= cache[secondSIndex][j].substitute1){
                    highestN = cache[secondSIndex][j].substitute1;
                }
            }
            for(int j = 0; j < associate; j++){
                if(highestN == cache[secondSIndex][j].substitute1){
                    cache[secondSIndex][j].label = secondTIndex;
                    cache[secondSIndex][j].substitute1 = 0;
                    for(int k = 0; k < associate; k++){
                        if(j==k){
                            
                        }else{
                            cache[secondSIndex][k].substitute1--;
                        }
                    }
                    break;
                }
            }
            return;
        }else if(cache[secondSIndex][i].reasonable==0){
            numR++;
            cache[secondSIndex][i].reasonable=1;
            cache[secondSIndex][i].label=secondTIndex;
            cache[secondSIndex][i].substitute1=0;
            for(int j=0;j<associate;j++){
                if(i==j){        
                }else{
                    cache[secondSIndex][j].substitute1--;
                }
            }                     
            break;
        }
        else
            continue;
    }
}
    void accesss(char,int ,int ,int , unsigned long int , unsigned long int ,unsigned long int ,unsigned long int );
    void accesss(char status ,int prefetch1ch,int policy,int associate, unsigned long int tagindex, unsigned long int setindex,unsigned long int secondTIndex,unsigned long int secondSIndex){
        if(policy==0){
            if(prefetch1ch==0){
                for(int i=0;i<associate;i++){
                    if(cache[setindex][i].reasonable==1&&cache[setindex][i].label==tagindex){
                        strike ++;
                        if(status=='W'){
                          numW++;
                    }
                    break;
                }
                else if(cache[setindex][i].reasonable==1&&associate==i+1){
                    miss++;
                    numR++;
                      if(status=='W'){
                        numW++;
                    }
                    long int highestN=LONG_MAX;
                    for(int j=0;j<associate;j++){
                        if(highestN>=cache[setindex][j].substitute){
                            highestN=cache[setindex][j].substitute;
                        }
                    }
                    for(int j=0;j<associate;j++){
                        if(highestN==cache[setindex][j].substitute){
                            cache[setindex][j].label=tagindex;
                            cache[setindex][j].substitute=press;
                            press++;
                            break;
                        }
                    }
                    return;
                }else if(cache[setindex][i].reasonable==0){
                    miss++;
                    numR++;
                    if(status=='W'){
                        numW++;
                    }
                    cache[setindex][i].reasonable=1;
                    cache[setindex][i].label=tagindex;
                    cache[setindex][i].substitute=press;
                    press++;
                    break;
                }
                else
                    continue;
            }
        }else{
            for(int i=0;i<associate;i++){
                if(cache[setindex][i].reasonable==1&&cache[setindex][i].label==tagindex){
                    strike ++;
                    if(status=='W'){
                        numW++;
                    }
                    break;
                }
                else if(cache[setindex][i].reasonable==1&&associate==i+1){
                    miss++;
                    numR++;
                    if(status=='W'){
                        numW++;
                    }
                    long int highestN=LONG_MAX;
                    for(int j=0;j<associate;j++){
                        if(highestN>=cache[setindex][j].substitute){
                            highestN=cache[setindex][j].substitute;
                        }
                    }
                    for(int j=0;j<associate;j++){
                        if(highestN==cache[setindex][j].substitute){
                            cache[setindex][j].label=tagindex;
                            cache[setindex][j].substitute=press;
                            press++;
                            break;
                        }
                    }
                    prefetch1(associate,secondSIndex,secondTIndex);
                    return;
                }else if(cache[setindex][i].reasonable==0){
                    miss++;
                    numR++;
                    if(status=='W'){
                        numW++;
                    }
                    cache[setindex][i].reasonable=1;
                    cache[setindex][i].label=tagindex;
                    cache[setindex][i].substitute=press;
                    press++;
                     prefetch1(associate,secondSIndex,secondTIndex);
                    break;
                }
                else
                    continue;
            }
        }
    }
    else if(policy==1){
        if(prefetch1ch==0){
            for(int i=0;i<associate;i++){
                if(cache[setindex][i].reasonable==1&&cache[setindex][i].label==tagindex){
                    strike ++;
                    if(status=='W'){
                        numW++;
                    }
                    
                    cache[setindex][i].substitute1=0;
                    for(int j=0;j<associate;j++){
                        if(i==j){
                            
                        }else{
                            cache[setindex][j].substitute1--;
                        }
                    }
                    
                    break;
                }
                else if(cache[setindex][i].reasonable==1&&associate==i+1){
                    miss++;
                    numR++;
                    if(status=='W'){
                        numW++;
                    }
                    long int highestN=LONG_MAX;
                    for(int j=0;j<associate;j++){
                        if(highestN>=cache[setindex][j].substitute1){
                            highestN=cache[setindex][j].substitute1;
                        }
                    }
                    for(int j=0;j<associate;j++){
                        if(highestN==cache[setindex][j].substitute1){
                            cache[setindex][j].label=tagindex;
                            cache[setindex][j].substitute1=0;
                            for(int k=0;k<associate;k++){
                                if(j==k){
                                    
                                }else{
                                    cache[setindex][k].substitute1--;
                                }
                            }
                            break;
                        }
                    }
                    return;
                }else if(cache[setindex][i].reasonable==0){
                    miss++;
                    numR++;
                    if(status=='W'){
                        numW++;
                    }
                    cache[setindex][i].reasonable=1;
                    cache[setindex][i].label=tagindex;
                    
                    
                    cache[setindex][i].substitute1=0;
                    for(int j=0;j<associate;j++){
                        if(i==j){
                            
                        }else{
                            cache[setindex][j].substitute1--;
                        }
                    }
                    
                    
                    break;
                }
                else
                    continue;
            }
        }else{
            for(int i=0;i<associate;i++){
                if(cache[setindex][i].reasonable==1&&cache[setindex][i].label==tagindex){
                    strike ++;
                    if(status=='W'){
                        numW++;
                    }
                    cache[setindex][i].substitute1=0;
                    for(int j=0;j<associate;j++){
                        if(i==j){
                            
                        }else{
                            cache[setindex][j].substitute1--;
                        }
                    }
                    
                    break;
                }
                else if(cache[setindex][i].reasonable==1&&associate==i+1){
                    miss++;
                    numR++;
                    if(status=='W'){
                        numW++;
                    }
                    long int highestN=LONG_MAX;
                    for(int j=0;j<associate;j++){
                        if(highestN>=cache[setindex][j].substitute1){
                            highestN=cache[setindex][j].substitute1;
                        }
                    }
                    for(int j=0;j<associate;j++){
                        if(highestN==cache[setindex][j].substitute1){
                            cache[setindex][j].label=tagindex;
                            cache[setindex][j].substitute1=0;
                            for(int k=0;k<associate;k++){
                                if(j==k){
                                    
                                }else{
                                    cache[setindex][k].substitute1--;
                                }
                            }
                            break;
                        }
                    }
                    prefetchclrue(associate,secondSIndex,secondTIndex);
                    return;
                }else if(cache[setindex][i].reasonable==0){
                    miss++;
                    numR++;
                    if(status=='W'){
                        numW++;
                    }
                    cache[setindex][i].reasonable=1;
                    cache[setindex][i].label=tagindex;
                    
                    
                    cache[setindex][i].substitute1=0;
                    for(int j=0;j<associate;j++){
                        if(i==j){
                            
                        }else{
                            cache[setindex][j].substitute1--;
                        }
                    }
                    
                    prefetchclrue(associate,secondSIndex,secondTIndex);
                    break;
                }
                else
                    continue;
            }
        }
    }
}



int main(int argc, char** argv){
    if(argc!=6)
        return 0;
    cache=initialize(argv);
    int associate=narrowA(argv);
    int block=blockArea(argv);
    int set=setNumber(argv);
    
    char* bo=argv[3];
    int ExtraCredit=eCredti(bo);
    char status;
    unsigned long int inscription;
    unsigned long int firstco;
    FILE* fl=fopen(tracedoc(argv), "r");
    int val=fscanf(fl, "%lx: %c %lx",&firstco,&status,&inscription);
    int switcher=0;
    while(val==3){
        int segment=log2(block);
        int sIndexb=log2(set);
        int sum=segment+sIndexb;
        unsigned long int tagindex=hint(inscription,sum);
        unsigned long int setindex=sIndex(inscription, segment, sIndexb);
        unsigned long int secondaddress=inscription+block;
        unsigned long int secondTIndex=hint(secondaddress,sum);
        unsigned long int secondSIndex=sIndex(secondaddress, segment, sIndexb);
        accesss(status,switcher,ExtraCredit, associate, tagindex, setindex, secondTIndex, secondSIndex);
        if(switcher==1)
            print();
        val = fscanf(fl, "%lx: %c %lx",&firstco,&status,&inscription);
        if(val!=3){
            switcher++;
            if(switcher==1){
                printf("Prefetch 0\n");
                printf("Memory reads: %d\n",numR);
                printf("Memory writes: %d\n",numW);
                printf("Cache hits: %d\n",strike );
                printf("Cache misses: %d\n",miss);
            }else if(switcher==2){
                printf("Prefetch 1\n");
                printf("Memory reads: %d\n",numR);
                printf("Memory writes: %d\n",numW);
                printf("Cache hits: %d\n",strike );
                printf("Cache misses: %d\n",miss);
                
                break;
            }else{
                break;
            }
            fl=fopen(tracedoc(argv), "r");
            val=fscanf(fl, "%lx: %c %lx",&firstco,&status,&inscription);
            cache=initialize(argv);
        }
    }
    return 0;
}

